package com.library.exception;

public class LibrarianException extends Exception{

	public LibrarianException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
