package com.library.dao;

import java.io.IOException;
import java.sql.SQLException;

import com.library.bean.Student;

public interface StudentDetailsDAO {
	
	public Boolean addStudentDetails(Student student) throws ClassNotFoundException, IOException, SQLException;
}
