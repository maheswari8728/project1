package com.library.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.library.bean.Librarian;

public interface ILibrarianDAO {
	
	public String addBook(Librarian librarian)throws ClassNotFoundException, IOException, SQLException;
	public Librarian viewBookDetails(int book_id)throws  IOException, SQLException;
	public List<Librarian> retrieveAll()throws  IOException, SQLException;

	
}
