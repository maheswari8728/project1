package com.library.pl;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.library.bean.Librarian;
import com.library.bean.Student;
import com.library.exception.LibrarianException;
import com.library.service.ILibrarianService;
import com.library.service.LibrarianServiceImpl;
import com.library.service.StudentDetailsService;
import com.library.service.StudentDetailsServiceImpl;

public class LibraryMain {
	
	static Scanner s = new Scanner(System.in);
	static ILibrarianService librarianService = null;
	static LibrarianServiceImpl librarianServiceimpl = null;
	static StudentDetailsService studentDetailsService = null;
	static StudentDetailsServiceImpl studentDetailsServiceImpl = null;

	public static void main(String[] args) throws ClassNotFoundException, IOException, SQLException {

		Librarian librarian = null;
		Student student = null;
		int ch = 0;
		int option = 0;

		do {

			System.out.println("\n Library Management");
			System.out.println("1.Librarian - Manage Books");
			System.out.println("2.Student - Issue Book");
			System.out.println("3.Exit Application");
			System.out.println(".....................................");
			System.out.println("Select option(1 or 2 or 3)\n");
			try {
				ch = s.nextInt();

				switch (ch) {
				case 1:
					System.out.println("1.Add book");
					System.out.println("2.View book");
					System.out.println("3.Retrieve All Books");
					System.out.println(".........................................");
					System.out.println("Select an option(1 or 2 or 3)\n");

					option = s.nextInt();

					switch (option) {

					case 1:
						while (librarian == null) {
							librarian = populateLibrarian();
						}
						try {
							librarianService = new LibrarianServiceImpl();
							String success = librarianService.addBook(librarian);
							if (success!=null)
								System.out.println("Book1 details successfully added\n");
							else
								System.out.println(
										"Please Check - There is an already exising record with this book_id\n");
						}

						finally {
							librarianService = null;
							librarian = null;
						}
						ch = 0;
						break;

					case 2:
						librarianService = new LibrarianServiceImpl();
						System.out.println("Enter the book id to be viewed");
						int book_id = s.nextInt();
						Librarian lib = librarianService.viewBookDetails(book_id);
						if (lib == null) {
							System.out.println("Book details for id " + book_id + " does not exist in database");
							ch = 0;
							break;
						}
						System.out.println("Book details for id " + book_id);
						System.out.println("Book Name:  " + lib.getBook_name());
						System.out.println("Book Author: " + lib.getBook_author());
						System.out.println("Book Department: " + lib.getDept_name());
						ch = 0;
						break;

					case 3:
						librarianService = new LibrarianServiceImpl();
						List<Librarian> bookList = librarianService.retrieveAll();
						if (bookList == null) {
							System.out.println("The book list is empty");
							ch = 0;
							break;
						}
						for (Librarian book : bookList) {
							System.out.println("....Book details for id.." + book.getBook_id() + "...................");
							System.out.println("Book Name:  " + book.getBook_name());
							System.out.println("Book Author: " + book.getBook_author());
							System.out.println("Book Department: " + book.getDept_name());
						}
						ch = 0;
						break;

					default:
						System.out.println("Please choose the value from given options only\n and try again\n");
						ch = 0;
						break;
					}
					break;

				case 2:
					while (student == null) {
						student = populateStudentDetails();
					}

					try {
						studentDetailsService = new StudentDetailsServiceImpl();
						Boolean success = studentDetailsService.addStudentDetails(student);
						if (success)
							System.out.println("Student details successfully added\n");
						else
							System.out.println(
									"Please Check - Either the student id is already existing in database\n or The given Book id does not exists in the database\n");
					}

					finally {
						studentDetailsService = null;
						student = null;
					}

					ch = 0;
					break;

				case 3:
					System.exit(0);

				}
			} catch (InputMismatchException e) {
				s.nextLine();
				System.err.println("Please choose the value from given options only\n and try again\n");
				ch = 0;
			}
		}

		while (ch == 0);

	}

	private static Student populateStudentDetails() {

		Student student = new Student();

		System.out.println("Enter student name");
		student.setStu_name(s.next());

		System.out.println("Enter student id");
		student.setStu_id(s.nextInt());

		System.out.println("Enter book id");
		student.setBook_id(s.nextInt());

		DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");

		Calendar cal = Calendar.getInstance();
		String issueDate = formatter.format(cal.getTime());
		System.out.println("The issue date will be set to current date which is " + issueDate);
		try {
			student.setIssue_date(formatter.parse(issueDate));
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		System.out.println("Enter return date in the format dd-MM-yyyy");
		String returnDateString = s.next();

		Date returnDate = null;
		try {
			returnDate = formatter.parse(returnDateString);
			student.setReturn_date(returnDate);
		} catch (ParseException e) {
			System.out.println("Invalid data format");
		}
		student.setFine(0);
		return student;
	}

	private static Librarian populateLibrarian() {

		Librarian librarian = new Librarian();

		System.out.println("Enter the book details\n");

		System.out.println("Enter the book name\n");
		librarian.setBook_name(s.next());

		System.out.println("Enter the book Id\n");
		librarian.setBook_id(s.next());

		System.out.println("Enter the book author\n");
		librarian.setBook_author(s.next());

		System.out.println("Enter the department name\n");
		librarian.setDept_name(s.next());

		librarianServiceimpl = new LibrarianServiceImpl();
		try {
			librarianServiceimpl.validateLibrarian(librarian);
			return librarian;
			// TODO Auto-generated method stub
		} catch (LibrarianException librarianException) {
			System.err.println("Invalid data");
			System.err.println(librarianException.getMessage() + "\n try again");
			System.exit(0);
		}

		return librarian;
	}

}


