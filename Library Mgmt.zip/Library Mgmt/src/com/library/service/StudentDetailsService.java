package com.library.service;

import java.io.IOException;
import java.sql.SQLException;

import com.library.bean.Student;

public interface StudentDetailsService {
	
	public Boolean addStudentDetails(Student student) throws ClassNotFoundException, IOException, SQLException;

}
