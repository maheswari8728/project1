package com.library.bean;

import java.util.Date;

public class Student {
	private String stu_name;
	private int stu_id;
	private Date issue_date;
	private Date return_date;
	private int book_id;
	private float fine;
	
	public String getStu_name() {
		return stu_name;
	}
	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}
	
	public int getStu_id() {
		return stu_id;
	}
	public void setStu_id(int stu_id) {
		this.stu_id = stu_id;
	}
	public Date getIssue_date() {
		return issue_date;
	}
	public void setIssue_date(Date issue_date) {
		this.issue_date = issue_date;
	}
	public Date getReturn_date() {
		return return_date;
	}
	public void setReturn_date(Date return_date) {
		this.return_date = return_date;
	}
	public int getBook_id() {
		return book_id;
	}
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}
	public float getFine() {
		return fine;
	}
	public void setFine(float fine) {
		this.fine = fine;
	}
	
	@Override
	public String toString() {
		return "Student [stu_name=" + stu_name + ", stu_id=" + stu_id + ", issue_date=" + issue_date + ", return_date="
				+ return_date + ", book_id=" + book_id + ", fine=" + fine + "]";
	}


}
